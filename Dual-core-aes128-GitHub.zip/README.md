# Dual-Core AES-128 Encryption

SystemVerilog RTL implementation of a dual-core AES-128 encryption architecture.

## Tools
- SystemVerilog
- Icarus Verilog
- EDA Playground
- EPWave

## Architecture
Two independent AES-128 cores share a common 128-bit key and encrypt separate
128-bit plaintext blocks in parallel.

## AES stages
- Key Expansion
- AddRoundKey
- SubBytes
- ShiftRows
- MixColumns
- Final round without MixColumns

## Verification

Core 0:
- Plaintext: `00112233445566778899aabbccddeeff`
- Key: `000102030405060708090a0b0c0d0e0f`
- Expected ciphertext: `69c4e0d86a7b0430d8cdb78070b4c55a`
- Result: PASS

Core 1:
- Plaintext: `112233445566778899aabbccddeeff00`
- Key: `000102030405060708090a0b0c0d0e0f`
- Expected ciphertext: `0dbedd87a7840ae695de334e94d35e50`
- Result: PASS

## EDA Playground
Original shared playground:
https://edaplayground.com/x/Q9w6
