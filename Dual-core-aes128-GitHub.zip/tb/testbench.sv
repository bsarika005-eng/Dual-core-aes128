module tb;

    logic [127:0] plaintext0, plaintext1;
    logic [127:0] key;
    logic [127:0] ciphertext0, ciphertext1;

    dual_core_aes dut (
        .plaintext0(plaintext0),
        .plaintext1(plaintext1),
        .key(key),
        .ciphertext0(ciphertext0),
        .ciphertext1(ciphertext1)
    );

    initial begin
        $dumpfile("dump.vcd");
        $dumpvars(0,tb);

        key = 128'h000102030405060708090a0b0c0d0e0f;
        plaintext0 = 128'h00112233445566778899aabbccddeeff;
        plaintext1 = 128'h112233445566778899aabbccddeeff00;

        #100;

        $display("==============================================");
        $display("       DUAL-CORE AES-128 ENCRYPTION");
        $display("==============================================");
        $display("KEY         : %h", key);
        $display("");
        $display("CORE 0");
        $display("Plaintext   : %h", plaintext0);
        $display("Ciphertext  : %h", ciphertext0);
        $display("");
        $display("CORE 1");
        $display("Plaintext   : %h", plaintext1);
        $display("Ciphertext  : %h", ciphertext1);
        $display("");

        if (ciphertext0 == 128'h69c4e0d86a7b0430d8cdb78070b4c55a)
            $display("CORE 0 AES TEST : PASS");
        else
            $display("CORE 0 AES TEST : FAIL");

        if (ciphertext1 == 128'h0dbedd87a7840ae695de334e94d35e50)
            $display("CORE 1 AES TEST : PASS");
        else
            $display("CORE 1 AES TEST : FAIL");

        $display("");
        $display("SIMULATION COMPLETE");
        #10;
        $finish;
    end

endmodule
